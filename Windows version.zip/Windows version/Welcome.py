import os
import time
import wx
import sys

#Welcome Screen

os.system("start cv.jpg")
time.sleep(3)
os.system("taskkill /f /im  Microsoft.Photos.exe")



app = wx.App()

#Asks for subreddit

def Enter():
    frame = wx.Frame(None, -1,) 
    dlg = wx.TextEntryDialog(frame, "Please enter the name of the subreddit:",'Picture Frame of Reddit')
    dlg.SetValue("")
    if dlg.ShowModal() == wx.ID_OK:
        sub = dlg.GetValue()
    else:
        sys.exit()
    dlg.Destroy()
    return sub

#Asks for newest or most popular picture


def New():
    frame = wx.Frame(None, -1,)
    dlg = wx.MessageDialog(frame, "Click Yes if you'd like the newest picture. Click No if you'd like the most popular picture.",
        'Picture Frame of Reddit', wx.YES_NO)
    if dlg.ShowModal() == wx.ID_YES:
        sub = "/new"
    else:
        sub = ""
    dlg.Destroy()
    return sub

#Set Refresh Time

def TimeLen():
    frame = wx.Frame(None, -1,) 
    dlg = wx.TextEntryDialog(frame, "How often would you like to refresh the picture (Please type in Seconds):",'Picture Frame of Reddit')
    dlg.SetValue("")
    if dlg.ShowModal() == wx.ID_OK:
        sec = dlg.GetValue()
    else:
        os.system("TASKKILL /F /IM Microsoft.Photos.exe")
        sys.exit()

    dlg.Destroy()
    return sec




sub = Enter()
new = New()
sec = int(TimeLen())






def Status():
    frame = wx.Frame(None, -1,)
    dlg = wx.MessageDialog(frame, "Would you like to keep going?",
        'Picture Frame of Reddit', wx.YES_NO)
    if dlg.ShowModal() == wx.ID_NO:
        os.system("taskkill /f /im  Microsoft.Photos.exe")
        sys.exit()

    dlg.Destroy()





# HOW OFTEN THE "Do you still want to continue" BOX WILL APPEAR
con = 2
# con = 5 ---- will ask every 5 refreshes




execfile("RedditImg.py")

for x in xrange(1,100000000):
    os.system("Picture_Frame_of_Reddit.jpg")
    time.sleep(sec)
    if(x % con == 0):
        Status()
    execfile("RedditImg.py")
    os.system("taskkill /f /im  Microsoft.Photos.exe")



app.MainLoop()



