import urllib
import urllib2
import os
from bs4 import BeautifulSoup as soup

my_url1 = imgur_link


request_headers = {
"Accept-Language": "en-US,en;q=0.5",
"User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0",
"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
"Referer": "http://thewebsite.com",
"Connection": "keep-alive" 
}

request = urllib2.Request(my_url1, headers=request_headers)
contents = urllib2.urlopen(request).read()

page_soup = soup(contents, "html.parser") 

pic = str(page_soup)


pic_link_start = (pic.index('<link href="https://i.imgur.com/') + 12)

find_end = pic[pic_link_start:1000000]

pic_link_end = find_end.index('" ')

full_img_link = find_end[0:pic_link_end]

urllib.urlretrieve(full_img_link, "Picture_Frame_of_Reddit.jpg")