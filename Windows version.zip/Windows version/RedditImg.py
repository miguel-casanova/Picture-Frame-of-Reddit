import urllib
import urllib2
from bs4 import BeautifulSoup as soup
import wx
import cv2



#Establishing connection to specific subreddit

my_Url1 = "https://old.reddit.com/r/" + sub + new

request_Headers = {
"Accept-Language": "en-US,en;q=0.5",
"User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:40.0) Gecko/20100101 Firefox/40.0",
"Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
"Referer": "http://thewebsite.com",
"Connection": "keep-alive" 
}

request = urllib2.Request(my_Url1, headers=request_Headers)
contents = urllib2.urlopen(request).read()

page_soup = soup(contents, "html.parser") 








#Array made up of HTML code from each subreddit row

redditRows = []



for x in xrange(1,26):
	y = str(x)
	z = page_soup.findAll("div",{"data-rank":y})
	zz = str(z)
	redditRows.append(zz)



redditSite = "i.redd.it"
imgurSite = "imgur.com"
my_Url = "https://old.reddit.com/r/" + sub






#Methods that call other files to grab the picture


def redditPic(number):
	img_link_start = (number.index("data-url=")) + 10
	b = number[img_link_start:100000] 
	img_link_end = b.index('" ')
	full_link = b[0:img_link_end]
	return full_link

def imgurPic(number):
	try:
		imgur_link_start = (number.index('data-url="https://i.imgur') + 10) 
		b = number[imgur_link_start:100000] 
		imgur_link_end = b.index('" ')
		imgur_link = b[0:imgur_link_end]
		urllib.urlretrieve(imgur_link, "Picture_Frame_of_Reddit.jpg")
	except:
		imgur_link_start = (number.index('data-url="https://imgur') + 10) 
		b = number[imgur_link_start:100000] 
		imgur_link_end = b.index('" ')
		imgur_link = b[0:imgur_link_end]
		execfile("2ndSiteImgur.py")

def redditOrImgur(site):
	domain = site.index("data-domain=") + 13
	c = site[domain:100000]
	domain_end = c.index('"')
	source_site = c[0:domain_end]
	return source_site




#For Loop that searches each row in the subreddit for the first image on the page

for x in xrange(0,25):
	if(redditOrImgur(redditRows[x]) == "imgur.com" or redditOrImgur(redditRows[x]) == "i.redd.it"):
		if(redditOrImgur(redditRows[x]) == "i.redd.it"):
			linkToReddit = redditPic(redditRows[x])
			urllib.urlretrieve(linkToReddit, "Picture_Frame_of_Reddit.jpg")
			break
		else:
			imgurPic(redditRows[x])
			break

xx = x+1
if(xx == 25):
	print "Please try again"
	sys.exit()

